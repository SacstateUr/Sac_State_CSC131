import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.*;


public class Database {
	   private static BufferedReader pass;
	   public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException, IOException {
	        try (Scanner input = new Scanner(System.in)) {
	            String name = null;
	            String Password = null;
	            String Code = null;
	            String Item = null;
	            int choice=1;
	            char proceed = ' ';
	            
	            System.out.println("Do you have an account with us (Y,N)");
	            proceed = input.next().charAt(0);
	            if(proceed == 'Y'||proceed == 'y')
	            {
	                System.out.println("Please enter your username(no spaces)");
	                name = input.next();
		            if(SignIn(proceed,name,Password,input))
		            {
		            	System.out.println(name);
		                        while(choice==1||choice==2||choice==3||choice==4){
		                            try (BufferedReader br = new BufferedReader(new FileReader("Database/Prompt.txt"))) {
		                                String line;
		                                while ((line = br.readLine()) != null)
		                                    System.out.println(line);
		                        choice=input.nextInt();
		                        switch (choice){
		                            case 1: //create item;
		                            	CreateItem(Code,Item,name,input);
		                                break;
		                            case 2: //flag item
		                            	LostItem(Code,Item,name,input,choice);
		                                break;    
		                            case 3: //item information;
		                            	CheckItems(name);
		                                break;
		                            case 4: //delete item;
		                            	DeleteItem(name, Code, input);
			                            break;
		                            default: System.out.println("Logging out");
		                                break;
		                        }
		                        }
		                        }
		            }
	            }
	            else
	            {
	         	   Register(proceed,name,Password,input);	
	            }
	            System.out.println("Thank you have a great day!");            
	            input.close();
	      }
	  }
	   
	   
	   
	   public static void CreateItem(String Code, String Item, String name, Scanner input) throws IOException {
           System.out.println("What is the trackers serial code?");
           Code = input.next();
           System.out.println("What is the item?");
           Item = input.next();
           if(new File("Database/Missing/"+Code+".txt").exists()||new File("Database/TrackerIds/"+Code+".txt").exists())
           {
                System.out.println("Sorry that Tracker Id belongs to an existing item");         
           }
           else
           {
           try (PrintWriter writer = new PrintWriter("Database/"+name+"/Objects/Have/"+Code+".txt")) {
               writer.println(Item);
               writer.println(Code);
               writer.close();
           }         
           try (PrintWriter writer = new PrintWriter("Database/TrackerIds/"+Code+".txt")) {
               writer.close();
           }    
           }                      
		}
	   public static void LostItem(String Code, String Item, String name, Scanner input, int choice) throws IOException {
           System.out.println("What is the trackers serial code?");
           Code = input.next();
           System.out.println("If you have the item press 1, If you lost the item press 2");
           choice = input.nextInt();
	       switch (choice) {
	           case 1:
	               if(new File("Database/"+name+"/Objects/Lost/"+Code+".txt").exists())
	               {                                         
	                   try (PrintWriter writer = new PrintWriter("Database/"+name+"/Objects/Have/"+Code+".txt")) {
	                       try (BufferedReader br2 = new BufferedReader(new FileReader("Database/"+name+"/Objects/Lost/"+Code+".txt"))) {
	                           String st;
	                           while ((st = br2.readLine()) != null)
	                               writer.println(st);
	                           writer.close();
	                       }
	                       new File("Database/"+name+"/Objects/Lost/"+Code+".txt").delete();
	                       new File("Database/Missing/"+Code+".txt").delete();
	                   }  
	               }
	               else
	                   System.out.println("Either that item is already maked as 'Have' or does not exist");
	               if(new File("Database/"+name+"/Objects/Found/"+Code+".txt").exists())
	               {
	                   new File("Database/"+name+"/Objects/Found/"+Code+".txt").delete();
	               }
	               break;
	           case 2:
	               if(new File("Database/"+name+"/Objects/Have/"+Code+".txt").exists())
	               {
	                   try (PrintWriter writer = new PrintWriter("Database/"+name+"/Objects/Lost/"+Code+".txt"); BufferedReader br2 = new BufferedReader(new FileReader("Database/"+name+"/Objects/Have/"+Code+".txt"))) {
	                       String st;
	                       while ((st = br2.readLine()) != null) 
	                           writer.println(st);
	                       new File("Database/"+name+"/Objects/Have/"+Code+".txt").delete(); 
	                       writer.close();
	                   }
	                   try (PrintWriter writer = new PrintWriter("Database/Missing/"+Code+".txt")) {
	                       writer.println(name);                            
	                   }
	               }
	               else
	                   System.out.println("Either that item is already maked as 'Lost' or does not exist");
	               break;
           default:
               System.out.println("sorry that wasnt a valid option");
               break;
       }
	   }
	   public static void CheckItems(String name) throws IOException  {
           System.out.println("Items that You Have");
           System.out.println("Item name"+"          "+"Tracker ID");
           String[] fileList = new File("Database/"+name+"/Objects/Have").list();
           if(fileList.length>0)
           {
           for(String file : fileList){
               try (BufferedReader br2 = new BufferedReader(new FileReader("Database/"+name+"/Objects/Have/"+file))) {
                   String line2;
                   while ((line2 = br2.readLine()) != null) 
                       System.out.print(line2+"                  ");
                   br2.close();
               }                                        
               System.out.println();
           }    
           }
           System.out.println("\nItems that You Lost");
           System.out.println("Item name"+"          "+"Tracker ID"+"          "+"Location");
           String[] fileList2 = new File("Database/"+name+"/Objects/Lost").list();
           if(fileList2.length>0)
           {
           for(String file2 : fileList2){
               if(new File("Database/"+name+"/Objects/Lost/"+file2).exists()){
                   try (BufferedReader br3 = new BufferedReader(new FileReader("Database/"+name+"/Objects/Lost/"+file2))) {
                       String line3;
                       while ((line3 = br3.readLine()) != null) 
                           System.out.print(line3+"                  ");
                       br3.close();
                   } 
               }
               if(new File("Database/"+name+"/Objects/Found/"+file2).exists()){
                   try (BufferedReader br4 = new BufferedReader(new FileReader("Database/"+name+"/Objects/Found/"+file2))) {
                       String line4;
                       while ((line4 = br4.readLine()) != null)
                           System.out.print(line4);
                       br4.close();
                   }  
               }
               else
                   System.out.print("N/A");
               System.out.println();
           }    
           }

	   }
   	   public static void DeleteItem(String name, String Code, Scanner input) throws IOException{
	   		System.out.println("What is the trackers serial code?");
	        Code = input.next();   
	        if(new File("Database/"+name+"/Objects/Lost/"+Code+".txt").exists()||new File("Database/"+name+"/Objects/Have/"+Code+".txt").exists())
	        {
	        if(new File("Database/"+name+"/Objects/Lost/"+Code+".txt").exists())
	            new File("Database/"+name+"/Objects/Lost/"+Code+".txt").delete();                                    
	        if(new File("Database/"+name+"/Objects/Found/"+Code+".txt").exists())
	            new File("Database/"+name+"/Objects/Found/"+Code+".txt").delete();
	        if(new File("Database/"+name+"/Objects/Have/"+Code+".txt").exists())
	            new File("Database/"+name+"/Objects/Have/"+Code+".txt").delete();
	        if(new File("Database/Missing"+Code+".txt").exists())
	            new File("Database/Missing"+Code+".txt").delete();
	        if(new File("Database/TrackerIds"+Code+".txt").exists())
	            new File("Database/TrackerIds"+Code+".txt").delete();
	        System.out.println("Item purged from our records");
	        }
	        else
	            System.out.println("That Item is not yours");
   	   }
	   public static void Notifyphone(String Code) throws IOException {
	        try (PrintWriter writer = new PrintWriter("Database/Missing/"+Code+".txt")) {
	             writer.println(Code);                            
	        }
	   }
	   public static void Register(char proceed, String name, String Password, Scanner input) throws IOException {
           System.out.println("Would you like to register a new account (Y,N)");
           proceed = input.next().charAt(0);
           if(proceed == 'Y'||proceed == 'Y')
           {
               System.out.println("Please enter a username(no spaces)");
               name = input.next();
               new File("Database/"+name).mkdir();
               try (PrintWriter writer = new PrintWriter("Database/"+name+"/Password.txt")) {
                   System.out.println("Welcome " + name + " Please enter a password");
                   Password = input.next();
                   writer.println(Password);
                   writer.close();
               }
               File dir2 = new File("Database/"+name+"/Objects/Have");
               dir2.mkdirs();
               File dir3 = new File("Database/"+name+"/Objects/Found");
               dir3.mkdir();
               File dir4 = new File("Database/"+name+"/Objects/Lost");
               dir4.mkdir();                    
               System.out.println("Thank you for registering an account with us!");
           }

	   }
	   public static boolean SignIn(char proceed, String name, String Password, Scanner input) throws IOException {
        
               if(new File("Database/"+name).exists())
               {
                   System.out.println("Welcome " + name + " Please enter your password");
                   Password = input.next();
                   pass = new BufferedReader(new FileReader("Database/"+name+"/Password.txt"));
                   if(Password.equals(pass.readLine()))
                	   return true;
                   else 
                   {
                	   System.out.println("Sorry that password is incorrect");  
                   	   return false;
                   }
               }  
           else
           {
               System.out.println("Sorry that user does not exist");
           	   return false;
           }
	   }
}
